// Thread worker : exécute la sandbox Luau/WASM pour qu'un timeout puisse tuer le thread proprement.
import { parentPort, workerData } from "node:worker_threads";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { runSandbox } from "./engine.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const harness = readFileSync(join(here, "harness.lua"), "utf8");
const { source, options } = workerData;

try {
  const result = await runSandbox({
    source,
    harness,
    options,
    post: (m) => parentPort.postMessage(m),
  });
  parentPort.postMessage({ type: "done", result });
} catch (err) {
  parentPort.postMessage({ type: "fatal", message: String((err && err.message) || err) });
}
