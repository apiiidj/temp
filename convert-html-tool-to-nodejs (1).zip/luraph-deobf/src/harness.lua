--!nonstrict
-- ============================================================================
--  Luraph sandbox harness (runs inside Luau / WASM)
--  Executes an obfuscated script against a *simulated Roblox environment* and
--  records every observable API call, assignment, loadstring payload ... then
--  streams them back to JS which rebuilds a readable script.
--
--  Injected from JS:
--    __emit(depth, text, id, name) -> index     __patch(index, text)
--    __used(id)    __payload(kind, text)        __loadstring(src, chunk)
--    __source      __runCallbacks  __maxLines   __placeId (optional)
-- ============================================================================

local rawtype, rawtypeof = type, typeof
local pcall, xpcall, error, select, next = pcall, xpcall, error, select, next
local setmetatable, getmetatable, rawget, rawset, rawequal = setmetatable, getmetatable, rawget, rawset, rawequal
local sfmt, srep, ssub, sgsub, smatch, sbyte, sfind = string.format, string.rep, string.sub, string.gsub, string.match, string.byte, string.find
local tconcat, tunpack = table.concat, table.unpack
local realGlobals = getfenv(0)
local realSetfenv = setfenv
local clock = os.clock
local rtostring = tostring

local HALT, STOP = {}, {}   -- sentinel errors (global halt / current-thread stop)

local depth, lineCount = 0, 0
local MAXLINES = __maxLines or 30000
local runCb = __runCallbacks ~= false
local info = setmetatable({}, { __mode = "k" })      -- mock -> metadata
local fnNames = setmetatable({}, { __mode = "k" })   -- function -> printable name
local nameCount = {}
local fnCounter, varCounter, payloadCounter, nextId = 0, 0, 0, 0
local cbDepth = 0
local waitsLeft = 300
local lastText, repeats = nil, 0

local KEYWORDS = {}
for w in ("and break do else elseif end false for function if in local nil not or repeat return then true until while"):gmatch("%a+") do
	KEYWORDS[w] = true
end

local function isIdent(s)
	return rawtype(s) == "string" and smatch(s, "^[%a_][%w_]*$") ~= nil and not KEYWORDS[s]
end

-- ---------------------------------------------------------------- formatting
local ESC = { ["\n"] = "\\n", ["\r"] = "\\r", ["\t"] = "\\t", ["\\"] = "\\\\", ['"'] = '\\"' }

local function q(s)
	if #s > 200000 then s = ssub(s, 1, 200000) .. "..." end
	local pat = '[%c"\\]'
	if not utf8.len(s) then pat = '[%c"\\\128-\255]' end
	local r = sgsub(s, pat, function(c)
		return ESC[c] or sfmt("\\%03d", sbyte(c))
	end)
	return '"' .. r .. '"'
end

local function fnum(n)
	if n ~= n then return "0/0" end
	if n == math.huge then return "math.huge" end
	if n == -math.huge then return "-math.huge" end
	if n % 1 == 0 and math.abs(n) < 1e15 then return sfmt("%d", n) end
	return sfmt("%.14g", n)
end

local function emit(text, id, name, dedupe)
	if dedupe then
		if text == lastText then
			repeats += 1
			if repeats > 400 then error(STOP, 0) end
			if repeats > 6 then return -1 end
		else
			lastText, repeats = text, 0
		end
	else
		lastText, repeats = nil, 0
	end
	lineCount += 1
	if lineCount > MAXLINES then error(HALT, 0) end
	return __emit(depth, text, id, name)
end

local function patch(idx, text)
	if idx and idx >= 0 then __patch(idx, text) end
end

local function markUsed(i)
	if not i.used then
		i.used = true
		if i.id then __used(i.id) end
	end
end

local function ref(m)
	local i = info[m]
	markUsed(i)
	return i.name or i.expr
end

local fmt

local function keyAcc(k)
	local t = rawtype(k)
	if t == "string" then
		if isIdent(k) then return "." .. k end
		return "[" .. q(k) .. "]"
	end
	return "[" .. fmt(k) .. "]"
end

local function fmtTable(t, d, seen)
	if seen[t] or d > 3 then return "{...}" end
	seen[t] = true
	local parts, n = {}, 0
	local len = rawlen(t)
	for i = 1, len do
		n += 1
		if n > 60 then parts[#parts + 1] = "..."; break end
		parts[#parts + 1] = fmt(rawget(t, i), d + 1, seen)
	end
	if n <= 60 then
		for k, v in next, t do
			if not (rawtype(k) == "number" and k >= 1 and k <= len and k % 1 == 0) then
				n += 1
				if n > 60 then parts[#parts + 1] = "..."; break end
				local ks
				if isIdent(k) then ks = k else ks = "[" .. fmt(k, d + 1, seen) .. "]" end
				parts[#parts + 1] = ks .. " = " .. fmt(v, d + 1, seen)
			end
		end
	end
	seen[t] = nil
	if #parts == 0 then return "{}" end
	local s = "{ " .. tconcat(parts, ", ") .. " }"
	if #s > 160 then
		s = "{\n\t" .. tconcat(parts, ",\n\t") .. "\n}"
	end
	return s
end

fmt = function(v, d, seen)
	local t = rawtype(v)
	if t == "string" then return q(v)
	elseif t == "number" then return fnum(v)
	elseif t == "nil" then return "nil"
	elseif t == "boolean" then return v and "true" or "false"
	elseif t == "function" then
		local nm = fnNames[v]
		if not nm then
			fnCounter += 1
			nm = "fn" .. fnCounter
			fnNames[v] = nm
		end
		return nm
	elseif t == "table" then
		if info[v] then return ref(v) end
		return fmtTable(v, d or 0, seen or {})
	end
	return "<" .. rawtypeof(v) .. ">"
end

-- ------------------------------------------------------------------- mocks
local mockMT = {}

local function newMock(expr, parent, key)
	local m = setmetatable({}, mockMT)
	info[m] = { expr = expr, parent = parent, key = key }
	return m
end

local function sanitize(s)
	s = sgsub(s, "[^%w_]", "_")
	if smatch(s, "^%d") then s = "_" .. s end
	if s == "" or smatch(s, "^_+$") or KEYWORDS[s] then s = "v" end
	return s
end

local function uniqueName(base)
	local c = nameCount[base]
	if not c then
		nameCount[base] = 1
		return base
	end
	nameCount[base] = c + 1
	return base .. c
end

local NAMEKEYS = {
	GetService = true, FindFirstChild = true, WaitForChild = true, FindFirstChildOfClass = true,
	FindFirstChildWhichIsA = true, new = true, Create = true, CreateWindow = true, Window = true,
	CreateTab = true, AddTab = true, Tab = true, CreateSection = true, AddSection = true, Section = true,
	MakeWindow = true, MakeTab = true, NewWindow = true, NewTab = true, NewSection = true,
}

local function pickName(key, args, start)
	if isIdent(key) then
		if NAMEKEYS[key] then
			local a = args[start]
			if rawtype(a) == "string" and #a > 0 and #a <= 28 then return uniqueName(sanitize(a)) end
			if rawtype(a) == "table" and info[a] == nil then
				local n = rawget(a, "Name") or rawget(a, "Title")
				if rawtype(n) == "string" and #n > 0 and #n <= 28 then return uniqueName(sanitize(n)) end
			end
		elseif ssub(key, 1, 3) == "Get" and #key > 3 then
			return uniqueName(sanitize(ssub(key, 4, 4):lower() .. ssub(key, 5)))
		elseif key == "Clone" then
			return uniqueName("clone")
		end
	end
	varCounter += 1
	return "v" .. varCounter
end

local hoistNested, traceBody, traceFunction

local function params(a)
	local hi = 0
	for i = 1, #a do
		if info[a[i]].used then hi = i end
	end
	local p = {}
	for i = 1, hi do p[i] = "a" .. i end
	return tconcat(p, ", ")
end

traceBody = function(f, runArgs)
	depth += 1
	local a = { newMock("a1"), newMock("a2"), newMock("a3") }
	if runCb and cbDepth < 6 then
		cbDepth += 1
		local saved = waitsLeft
		waitsLeft = 4
		local ok, err
		if runArgs then
			ok, err = pcall(f, tunpack(runArgs, 1, runArgs.n or #runArgs))
		else
			ok, err = pcall(f, a[1], a[2], a[3])
		end
		waitsLeft = saved
		cbDepth -= 1
		if not ok then
			if err == HALT then
				depth -= 1
				error(HALT, 0)
			elseif err == STOP then
				emit("-- (loop cut: wait/repeat budget reached while tracing)")
			else
				emit("-- error while tracing: " .. ssub(rtostring(err), 1, 200))
			end
		end
	else
		emit("-- (callback not traced)")
	end
	depth -= 1
	return params(a)
end

traceFunction = function(f)
	fnCounter += 1
	local nm = "fn" .. fnCounter
	fnNames[f] = nm
	local h = emit("local function " .. nm .. "()")
	local p = traceBody(f)
	patch(h, "local function " .. nm .. "(" .. p .. ")")
	emit("end")
	return nm
end

hoistNested = function(v, d, seen)
	local t = rawtype(v)
	if t == "function" then
		if not fnNames[v] then traceFunction(v) end
	elseif t == "table" and not info[v] and d < 4 and not seen[v] then
		seen[v] = true
		local n = 0
		for _, x in next, v do
			n += 1
			if n > 120 then break end
			hoistNested(x, d + 1, seen)
		end
	end
end

local function traceCall(callText, args, n, start, hint, wantResult, runArgs)
	local inlineIdx
	local last = args[n]
	if n >= start and rawtype(last) == "function" and not fnNames[last] then inlineIdx = n end
	for i = start, n do
		if i ~= inlineIdx then hoistNested(args[i], 0, {}) end
	end
	local parts = {}
	local stop = inlineIdx and (n - 1) or n
	for i = start, stop do parts[#parts + 1] = fmt(args[i]) end

	local res, rname, rid
	if wantResult then
		rname = pickName(hint, args, start)
		nextId += 1
		rid = nextId
		res = newMock(rname)
		local ri = info[res]
		ri.name, ri.id = rname, rid
	end
	local pre = (wantResult and "\1" or "") .. callText .. "(" .. tconcat(parts, ", ")
	if inlineIdx then
		local f = args[inlineIdx]
		fnCounter += 1
		fnNames[f] = "fn" .. fnCounter
		local sep = #parts > 0 and ", " or ""
		local h = emit(pre .. sep .. "function()", rid, rname)
		local p = traceBody(f, runArgs)
		patch(h, pre .. sep .. "function(" .. p .. ")")
		emit("end)")
	else
		emit(pre .. ")", rid, rname, true)
	end
	return res
end

local function assignTo(lhs, v)
	if rawtype(v) == "function" and not fnNames[v] then
		fnNames[v] = lhs
		local h = emit(lhs .. " = function()")
		local p = traceBody(v)
		patch(h, lhs .. " = function(" .. p .. ")")
		emit("end")
	else
		hoistNested(v, 0, {})
		emit(lhs .. " = " .. fmt(v), nil, nil, true)
	end
end


-- --------------------------------------------------- Roblox EncodingService
-- Luraph >= 14.x ships its bytecode compressed and calls
--   game:GetService("EncodingService"):DecompressBuffer(buf, Enum.CompressionAlgorithm.Zstd)
-- We provide a *real* implementation (zstd is done on the JS side).
local function bufToHex(b)
	local str = buffer.tostring(b)
	return (sgsub(str, ".", function(c) return sfmt("%02x", sbyte(c)) end))
end
local function hexToBuf(h)
	return buffer.fromstring((sgsub(h, "%x%x", function(x) return string.char(tonumber(x, 16)) end)))
end
local function algoName(a)
	if info[a] then return (info[a].expr:match("([%w_]+)$")) or "Zstd" end
	return rtostring(a)
end
local encodingService
encodingService = {
	DecompressBuffer = function(_, buf, algo)
		local res, derr = __zstd(bufToHex(buf), algoName(algo))
		if not res then error("DecompressBuffer failed: " .. rtostring(derr), 2) end
		__blob("zstd", res)
		return hexToBuf(res)
	end,
	CompressBuffer = function(_, buf)
		return buf
	end,
}

mockMT.__index = function(self, k)
	local si = info[self]
	if __dbg then __dbg("index " .. si.expr .. " . " .. rtostring(k)) end
	local kt = rawtype(k)
	local cache = si.kids
	local cacheable = (kt == "string" or kt == "number")
	if cacheable and cache then
		local c = cache[k]
		if c then return c end
	end
	if si.expr == "game" and __placeId and (k == "PlaceId" or k == "GameId") then
		return __placeId
	end
	local m = newMock(ref(self) .. keyAcc(k), self, k)
	if cacheable then
		if not cache then
			cache = {}
			si.kids = cache
		end
		cache[k] = m
	end
	return m
end

mockMT.__newindex = function(self, k, v)
	assignTo(ref(self) .. keyAcc(k), v)
end

mockMT.__call = function(self, ...)
	local n = select("#", ...)
	if __dbg then __dbg("call " .. info[self].expr .. " n=" .. n) end
	local args = { ... }
	local si = info[self]
	markUsed(si)
	if si.key == "GetService" and args[2] == "EncodingService" then return encodingService end
	local start, callText = 1, nil
	local p = si.parent
	if p ~= nil and n >= 1 and rawequal(args[1], p) and isIdent(si.key) then
		start = 2
		callText = ref(p) .. ":" .. si.key
	else
		callText = si.name or si.expr
	end
	return traceCall(callText, args, n, start, si.key, true)
end

local function binop(op)
	return function(a, b)
		return newMock("(" .. fmt(a) .. " " .. op .. " " .. fmt(b) .. ")")
	end
end
mockMT.__add, mockMT.__sub, mockMT.__mul, mockMT.__div = binop("+"), binop("-"), binop("*"), binop("/")
mockMT.__mod, mockMT.__pow, mockMT.__idiv, mockMT.__concat = binop("%"), binop("^"), binop("//"), binop("..")
mockMT.__unm = function(a) return newMock("(-" .. fmt(a) .. ")") end
mockMT.__len = function() return 0 end
mockMT.__lt = function() return false end
mockMT.__le = function() return false end
mockMT.__tostring = function(m) return ref(m) end
mockMT.__iter = function() return function() return nil end end

-- --------------------------------------------------------------- environment
local env = {}
local dbgN = 0
local function def(k, v)
	if __dbg and rawtype(v) == "function" and k ~= "type" and k ~= "typeof" then
		local orig = v
		v = function(...)
			dbgN += 1
			if true then __dbg("fn " .. k .. " (" .. select("#", ...) .. " args)") end
			return orig(...)
		end
	end
	rawset(env, k, v)
end

for _, name in ipairs({
	"assert", "collectgarbage", "error", "getmetatable", "ipairs", "next", "pairs", "rawequal", "rawget",
	"rawlen", "rawset", "select", "setmetatable", "tonumber", "tostring", "unpack", "_VERSION", "string",
	"table", "math", "bit32", "buffer", "utf8", "coroutine", "newproxy",
}) do
	local v = realGlobals[name]
	if __dbg and rawtype(v) == "table" and name ~= "string" then
		local w = {}
		for k2, f in next, v do
			if rawtype(f) == "function" then
				w[k2] = function(...)
					dbgN += 1
					if true then __dbg("lib " .. name .. "." .. k2 .. " (" .. select("#", ...) .. ")") end
					return f(...)
				end
			else
				w[k2] = f
			end
		end
		v = w
	end
	def(name, v)
end

def("type", function(v)
	if __dbg then dbgN += 1; if true then __dbg("type " .. rawtype(v)) end end
	if info[v] then return "userdata" end
	return rawtype(v)
end)
def("typeof", function(v)
	if info[v] then return "Instance" end
	return rawtypeof(v)
end)

local function chk(ok, ...)
	if not ok then
		local e = ...
		if e == STOP or e == HALT then error(e, 0) end
	end
	return ok, ...
end
def("pcall", function(f, ...) return chk(pcall(f, ...)) end)
def("xpcall", function(f, h, ...)
	return chk(xpcall(f, function(e)
		if e == STOP or e == HALT then return e end
		return h(e)
	end, ...))
end)

local realOs = {}
local function wrapos(k, f) if not __dbg then return f end return function(...) __dbg("os." .. k) return f(...) end end
for _, k in ipairs({ "time", "clock", "date", "difftime" }) do realOs[k] = wrapos(k, os[k]) end
def("os", setmetatable(realOs, { __index = function(_, k) return newMock("os." .. rtostring(k)) end }))

local dbg = { traceback = debug.traceback, info = debug.info }
dbg.getinfo = function()
	return { currentline = 1, source = "@script", short_src = "script", what = "Lua", name = "unknown", nups = 0, numparams = 0 }
end
def("debug", setmetatable(dbg, { __index = function(_, k) return newMock("debug." .. rtostring(k)) end }))

def("getfenv", function() return env end)
def("setfenv", function(f, t)
	if rawtype(f) == "function" then pcall(realSetfenv, f, t) end
	return f
end)

-- time / tasks -----------------------------------------------------------
local function doWait(callText, ...)
	waitsLeft -= 1
	if waitsLeft < 0 then error(STOP, 0) end
	traceCall(callText, { ... }, select("#", ...), 1, "wait", false)
	return 0.03, clock()
end
local function spawnLike(callText)
	return function(...)
		traceCall(callText, { ... }, select("#", ...), 1, "spawn", false)
		return newMock("thread")
	end
end

def("task", {
	wait = function(...) return doWait("task.wait", ...) end,
	spawn = spawnLike("task.spawn"),
	defer = spawnLike("task.defer"),
	delay = spawnLike("task.delay"),
	cancel = function() end,
	synchronize = function() end,
	desynchronize = function() end,
})
def("wait", function(...) return doWait("wait", ...) end)
def("spawn", spawnLike("spawn"))
def("delay", spawnLike("delay"))
def("defer", spawnLike("defer"))
def("tick", function() return os.time() + (clock() % 1) end)
def("time", function() return clock() end)
def("elapsedTime", function() return clock() end)

local function logOnly(name, ret)
	return function(...)
		traceCall(name, { ... }, select("#", ...), 1, name, false)
		if rawtype(ret) == "function" then return ret(...) end
		return ret
	end
end
def("print", logOnly("print"))
def("warn", logOnly("warn"))

-- executor-like helpers -----------------------------------------------------
def("identifyexecutor", logOnly("identifyexecutor", function() return "Synapse X", "2.0" end))
def("getexecutorname", logOnly("getexecutorname", "Synapse X"))
def("checkcaller", function() return true end)
def("newcclosure", function(f) return f end)
def("clonefunction", function(f) return f end)
def("islclosure", function() return true end)
def("iscclosure", function() return false end)
def("is_synapse_function", function() return false end)
def("isexecutorclosure", function() return false end)
def("hookfunction", logOnly("hookfunction", function(a) return a end))
def("hookmetamethod", logOnly("hookmetamethod", function() return function() end end))
def("getnamecallmethod", function() return "" end)
def("setnamecallmethod", function() end)
for _, nm in ipairs({
	"setclipboard", "toclipboard", "queue_on_teleport", "writefile", "appendfile", "makefolder", "delfile",
	"setfpscap", "rconsoleprint", "rconsolewarn", "messagebox", "firesignal", "fireclickdetector",
	"fireproximityprompt", "firetouchinterest",
}) do
	def(nm, logOnly(nm))
end
def("isfile", logOnly("isfile", false))
def("isfolder", logOnly("isfolder", false))
def("readfile", logOnly("readfile", ""))
for _, nm in ipairs({
	"listfiles", "getconnections", "getgc", "getinstances", "getnilinstances", "getloadedmodules", "getscripts", "getreg",
}) do
	def(nm, logOnly(nm, function() return {} end))
end
def("setreadonly", function() end)
def("isreadonly", function() return false end)
def("make_writeable", function() end)
def("make_readonly", function() end)
def("setrawmetatable", function(t, mt) return setmetatable(t, mt) end)
def("getrawmetatable", function(t) return getmetatable(t) or {} end)

local function httpResult(...)
	traceCall("request", { ... }, select("#", ...), 1, "request", false)
	return { Success = true, StatusCode = 200, StatusMessage = "OK", Body = "", Headers = {} }
end
def("request", httpResult)
def("http_request", httpResult)
def("httprequest", httpResult)

-- loadstring: record payloads and run them inside the same sandbox ----------
def("loadstring", function(src, chunkname)
	if rawtype(src) ~= "string" then
		local args = { src, chunkname }
		return traceCall("loadstring", args, chunkname ~= nil and 2 or 1, 1, "loadstring", true)
	end
	payloadCounter += 1
	local pid = payloadCounter
	__payload("loadstring", src)
	local shown
	if #src <= 400 then
		shown = q(src)
	else
		shown = "PAYLOAD_" .. pid .. " --[[ " .. #src .. " bytes, voir fichier .payload" .. pid .. ".lua ]]"
	end
	local fn, err = __loadstring(src, chunkname or ("=payload" .. pid))
	if not fn then
		emit("-- loadstring(PAYLOAD_" .. pid .. ") failed to compile: " .. ssub(rtostring(err), 1, 160))
		return nil, err
	end
	nextId += 1
	local rid = nextId
	local rname = "chunk" .. pid
	emit("\1loadstring(" .. shown .. ")", rid, rname)
	pcall(realSetfenv, fn, env)
	return function(...)
		__used(rid)
		emit("-- >>> executing payload #" .. pid .. " (" .. #src .. " bytes)")
		return fn(...)
	end
end)

-- global tables ----------------------------------------------------------------
local function loggedTable(label)
	return setmetatable({}, {
		__newindex = function(self, k, v)
			assignTo(label .. keyAcc(k), v)
			rawset(self, k, v)
		end,
	})
end
local genv = loggedTable("getgenv()")
def("getgenv", function() return genv end)
def("getrenv", function() return env end)
def("getsenv", function() return env end)
def("_G", loggedTable("_G"))
def("shared", loggedTable("shared"))

local NILGLOBALS = {
	bit = true, jit = true, arg = true, io = true, package = true, dofile = true, loadfile = true,
	load = true, module = true,
}

-- Luraph (anti-tamper) lit des globales à nom aléatoire (« YKbcQUwWMMiKs », « f3mtW2FsUUyt ») et
-- s'attend à recevoir nil, comme dans un vrai moteur Roblox. On ne leur fournit donc pas de mock.
local function looksRandom(k)
	local n = #k
	if n < 10 or sfind(k, "[^%w]") then return false end
	if (sfind(k, "%a%d%a") or sfind(k, "^%a%d")) and not sfind(k, "^%u%l+%d") then return true end
	local _, trans = sgsub(k, "%l%u", "")
	return trans >= 3 and n / (trans + 1) < 4.5
end

setmetatable(env, {
	__index = function(_, k)
		if rawtype(k) ~= "string" then return nil end
		if __dbg then __dbg("global " .. k) end
		if NILGLOBALS[k] or looksRandom(k) then return nil end
		local m = newMock(k)
		rawset(env, k, m)
		return m
	end,
	__newindex = function(t, k, v)
		assignTo(isIdent(k) and k or ("_G[" .. fmt(k) .. "]"), v)
		rawset(t, k, v)
	end,
})

-- ---------------------------------------------------------------------- run
local fn, err = __loadstring(__source, "=script")
if not fn then
	__emit(0, "-- SYNTAX ERROR: " .. rtostring(err), 0, "")
	return "syntax"
end
pcall(realSetfenv, fn, env)

local ok, e = pcall(fn)
if not ok then
	if e == HALT then
		__emit(0, "-- [halted: output limit reached (" .. MAXLINES .. " lines)]", 0, "")
	elseif e == STOP then
		__emit(0, "-- [stopped: infinite loop / wait budget exhausted]", 0, "")
	else
		__emit(0, "-- [script error] " .. ssub(rtostring(e), 1, 300), 0, "")
	end
end
return ok and "ok" or "error"
