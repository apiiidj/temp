// Drives the Luau (WASM) VM: loads the harness, injects bridge functions, runs the target script.
import { LuauState } from "luau-web";
import { decompress } from "fzstd";
// Conversions hex <-> octets (Buffer de Node : rapide et léger en mémoire sur Termux)
function hexToBytes(h) {
    return Uint8Array.from(Buffer.from(h, "hex"));
}
function bytesToHex(b) {
    return Buffer.from(b.buffer, b.byteOffset, b.byteLength).toString("hex");
}
export async function runSandbox({ source, harness, options = {}, post }) {
    let ops = [];
    let idx = 0;
    let lastFlush = Date.now();
    const flush = () => {
        lastFlush = Date.now();
        if (ops.length) {
            post({ type: "ops", ops });
            ops = [];
        }
    };
    const push = (op) => {
        ops.push(op);
        if (ops.length >= 50 || Date.now() - lastFlush > 250)
            flush();
    };
    // eslint-disable-next-line prefer-const
    let st;
    const env = {
        __emit: (depth, text, id, name) => {
            const i = idx++;
            push(["e", i, depth, String(text), id ?? 0, name ?? ""]);
            return i;
        },
        __patch: (i, text) => push(["p", i, String(text)]),
        __used: (id) => push(["u", id]),
        __payload: (kind, text) => { push(["pl", kind, String(text)]); flush(); },
        __loadstring: (src, name) => {
            try {
                return st.loadstring(src, name || "=chunk", true);
            }
            catch (e) {
                return [null, String(e?.message ?? e)];
            }
        },
        __zstd: (hex, algo) => {
            try {
                const out = decompress(hexToBytes(hex));
                return bytesToHex(out);
            }
            catch (e) {
                return [null, `${algo}: ${e?.message ?? e}`];
            }
        },
        __blob: (kind, hex) => { push(["bl", kind, hex.length >> 1, hex]); flush(); },
        __source: source,
        ...(options.debug ? { __dbg: globalThis.__dbgFn ?? ((m) => console.log("[dbg]", m)) } : {}),
        __runCallbacks: options.runCallbacks !== false,
        __maxLines: options.maxLines ?? 30000,
    };
    if (options.placeId)
        env.__placeId = options.placeId;
    st = await LuauState.createAsync(env);
    const fn = st.loadstring(harness, "=harness", true);
    let result;
    try {
        result = await fn();
    }
    finally {
        flush();
    }
    const r = Array.isArray(result) ? result[0] : result;
    return String(r ?? "ok");
}
