// Rebuilds a readable script from the stream of operations emitted by the Lua harness.
export function newState() {
    return { lines: [], used: new Set(), payloads: [], blobs: [] };
}
export function applyOps(state, ops) {
    for (const op of ops) {
        switch (op[0]) {
            case "e":
                state.lines[op[1]] = { depth: op[2], text: op[3], id: op[4], name: op[5] };
                break;
            case "p":
                if (state.lines[op[1]])
                    state.lines[op[1]].text = op[2];
                break;
            case "u":
                state.used.add(op[1]);
                break;
            case "pl":
                state.payloads.push({ kind: op[1], source: op[2] });
                break;
            case "bl":
                state.blobs.push({ kind: op[1], size: op[2], hex: op[3] });
                break;
        }
    }
}
const AUTO_NAME = /^v\d+$/;
const BLOCK_OPEN = /function\([^)]*\)$/;
export function render(state, opts = {}) {
    const inline = opts.inline !== false;
    const items = [];
    for (const l of state.lines) {
        if (!l)
            continue;
        const item = { depth: l.depth, text: l.text };
        if (l.text.includes("\u0001")) {
            if (l.id && state.used.has(l.id)) {
                item.text = l.text.replace("\u0001", `local ${l.name} = `);
                if (AUTO_NAME.test(l.name) && !BLOCK_OPEN.test(l.text)) {
                    item.defName = l.name;
                    item.defExpr = l.text.replace("\u0001", "");
                }
            }
            else {
                item.text = l.text.replace("\u0001", "");
            }
        }
        items.push(item);
    }
    if (inline) {
        // count every auto-generated temp (v123) once, then inline the single-use ones consumed by the next statement
        const WORD = /(^|[^A-Za-z0-9_.])(v\d+)(?![A-Za-z0-9_])/g;
        const counts = new Map();
        for (const it of items) {
            let m;
            WORD.lastIndex = 0;
            while ((m = WORD.exec(it.text)))
                counts.set(m[2], (counts.get(m[2]) || 0) + 1);
        }
        for (let i = 0; i < items.length - 1; i++) {
            const it = items[i];
            if (!it.defName)
                continue;
            if (counts.get(it.defName) !== 2)
                continue;
            const next = items[i + 1];
            if (next.depth !== it.depth)
                continue;
            const re = new RegExp(`(^|[^A-Za-z0-9_.])${it.defName}(?![A-Za-z0-9_])`);
            if (!re.test(next.text))
                continue;
            const expr = it.defExpr;
            next.text = next.text.replace(re, (_m, p1) => p1 + expr);
            if (next.defName && next.defExpr)
                next.defExpr = next.defExpr.replace(re, (_m, p1) => p1 + expr);
            items.splice(i, 1);
            i = Math.max(-1, i - 2);
        }
    }
    const out = items.map((it) => "\t".repeat(it.depth) + it.text);
    return { code: out.join("\n"), lineCount: out.length };
}
// ---------------------------------------------------------------- extraction
export function extractStrings(code) {
    const set = new Set();
    const re = /"((?:[^"\\\n]|\\.)*)"/g;
    let m;
    while ((m = re.exec(code))) {
        const s = m[1];
        if (s.length >= 3)
            set.add(s);
    }
    return [...set];
}
export function extractUrls(texts) {
    const set = new Set();
    const re = /https?:\/\/[^\s"'\\)<>]+/gi;
    for (const t of texts) {
        const found = t.match(re);
        if (found)
            found.forEach((u) => set.add(u));
    }
    return [...set];
}
export function extractRemoteCalls(code) {
    const keys = [
        "HttpGet", "HttpPost", "request(", "http_request", "loadstring", "setclipboard", "queue_on_teleport",
        "writefile", "FireServer", "InvokeServer", "SendAsync", "PostAsync", "GetAsync", "Webhook", "discord",
        "TeleportService", "Teleport(", "Kick(", "hookfunction", "hookmetamethod", "getgenv",
    ];
    const lines = code.split("\n");
    const hits = [];
    for (const l of lines) {
        const t = l.trim();
        if (keys.some((k) => t.includes(k)))
            hits.push(t.length > 220 ? t.slice(0, 220) + "…" : t);
    }
    return [...new Set(hits)].slice(0, 200);
}
