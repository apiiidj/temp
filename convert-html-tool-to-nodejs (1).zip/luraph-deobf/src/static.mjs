// Static (no execution) analysis helpers for Luraph scripts.
export function analyze(src) {
    const head = src.slice(0, 600);
    const vm = /Luraph Obfuscator v?(\d+(?:\.\d+){0,2})/i.exec(head);
    const body = head.replace(/^\s*--[^\n]*\n/, "").trimStart();
    let flavor = "Inconnu";
    let flavorNote = "Structure non reconnue — l'exécution en sandbox est tout de même possible.";
    if (/^local\s+v0\s*=\s*string\.char/.test(body)) {
        flavor = "Luraph « léger » (chaînes XOR + VM inline)";
        flavorNote =
            "Les chaînes sont chiffrées par XOR et le script ne dépend pas d'une empreinte du moteur Roblox : la sandbox le traite en général très bien.";
    }
    else if (/^return\s*\(\s*\{\s*[A-Za-z0-9_]+\s*=\s*function/.test(body)) {
        flavor = "Luraph VM « table de méthodes »";
        flavorNote =
            "Le script renvoie une table de méthodes (`return({xx=function…}):W()(...)`). Cette variante décompresse son bytecode via EncodingService (Zstd) et exécute un runtime qui interroge le moteur Roblox.";
    }
    else if (/^return\s*\(\s*function\s*\(\s*\)\s*local/.test(body)) {
        flavor = "Luraph VM « fermeture »";
        flavorNote = "Le script renvoie une grande fermeture contenant le désérialiseur et la VM.";
    }
    const markers = [];
    const probe = [
        [/bit32\.(?:countlz|countrz)/, "bit32.countlz/countrz (VM Luau)"],
        [/writeu32|readu32/, "buffer.writeu32 / readu32"],
        [/\bcontinue\b/, "mot-clé Luau `continue`"],
        [/getfenv|setfenv/, "getfenv / setfenv"],
        [/string\.char/, "string.char"],
        [/loadstring/, "loadstring"],
        [/HttpGet|HttpPost/, "HttpGet / HttpPost"],
    ];
    for (const [re, label] of probe)
        if (re.test(src))
            markers.push(label);
    let longest = 0;
    const lines = src.split("\n");
    for (const l of lines)
        if (l.length > longest)
            longest = l.length;
    return {
        size: src.length,
        lines: lines.length,
        luraph: !!vm || /Luraph/i.test(head),
        version: vm ? vm[1] : null,
        flavor,
        flavorNote,
        hexLiterals: (src.match(/\b0[xX][0-9a-fA-F_]+/g) || []).length,
        binLiterals: (src.match(/\b0[bB][01_]+/g) || []).length,
        underscoreLiterals: (src.match(/\b\d[\d]*_[\d_]*\b/g) || []).length,
        methodTableEntries: (src.match(/[,{]\s*[A-Za-z_][A-Za-z0-9_]*\s*=\s*function\s*\(/g) || []).length,
        endsWithEntry: /\)\s*:\s*[A-Za-z_][A-Za-z0-9_]*\s*\(\s*\)\s*\(\s*\.\.\.\s*\)\s*;?\s*$/.test(src.trimEnd()),
        longestLine: longest,
        markers,
    };
}
// ---------------------------------------------------------------- literals
// Rewrites Luraph-style numeric literals (0X27__D3, 0b1_0000_0, 1_000) into plain decimals,
// leaving strings and comments untouched.
export function normalizeLiterals(src) {
    let out = "";
    let i = 0;
    const n = src.length;
    const isIdent = (c) => /[A-Za-z0-9_]/.test(c);
    while (i < n) {
        const c = src[i];
        // comments
        if (c === "-" && src[i + 1] === "-") {
            const lm = /^--\[(=*)\[/.exec(src.slice(i, i + 40));
            if (lm) {
                const close = "]" + lm[1] + "]";
                const e = src.indexOf(close, i + lm[0].length);
                const end = e < 0 ? n : e + close.length;
                out += src.slice(i, end);
                i = end;
            }
            else {
                let e = src.indexOf("\n", i);
                if (e < 0)
                    e = n;
                out += src.slice(i, e);
                i = e;
            }
            continue;
        }
        // long strings
        if (c === "[") {
            const lm = /^\[(=*)\[/.exec(src.slice(i, i + 40));
            if (lm) {
                const close = "]" + lm[1] + "]";
                const e = src.indexOf(close, i + lm[0].length);
                const end = e < 0 ? n : e + close.length;
                out += src.slice(i, end);
                i = end;
                continue;
            }
        }
        // quoted strings
        if (c === '"' || c === "'") {
            let j = i + 1;
            while (j < n && src[j] !== c) {
                if (src[j] === "\\")
                    j++;
                j++;
            }
            out += src.slice(i, j + 1);
            i = j + 1;
            continue;
        }
        // numbers
        if (/[0-9]/.test(c) && (i === 0 || !isIdent(src[i - 1]))) {
            const rest = src.slice(i, i + 200);
            let m;
            if ((m = /^0[xX]([0-9a-fA-F_]+)(?![0-9A-Za-z.])/.exec(rest))) {
                const digits = m[1].replace(/_/g, "");
                out += digits ? BigInt("0x" + digits).toString() : m[0];
                i += m[0].length;
                continue;
            }
            if ((m = /^0[bB]([01_]+)(?![0-9A-Za-z.])/.exec(rest))) {
                const digits = m[1].replace(/_/g, "");
                out += digits ? BigInt("0b" + digits).toString() : m[0];
                i += m[0].length;
                continue;
            }
            if ((m = /^(?:\d[\d_]*)(?:\.[\d_]*)?(?:[eE][+-]?\d+)?/.exec(rest))) {
                out += m[0].replace(/_/g, "");
                i += m[0].length;
                continue;
            }
        }
        out += c;
        i++;
    }
    return out;
}
export function fmtBytes(n) {
    if (n < 1024)
        return `${n} o`;
    if (n < 1024 * 1024)
        return `${(n / 1024).toFixed(1)} Ko`;
    return `${(n / 1024 / 1024).toFixed(2)} Mo`;
}
