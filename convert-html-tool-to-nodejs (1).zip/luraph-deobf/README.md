# luraph-deobf — désobfuscateur Luraph en Node.js (compatible Termux)

Version ligne de commande de l'outil web « develop-luraph-deobfuscator-tool »
(React/Vite) : plus d'interface HTML, tout tourne dans le terminal.

## Principe

1. Le script `.lua` est exécuté dans une **sandbox Luau compilée en WebAssembly**
   (`luau-web`), à l'intérieur d'un **environnement Roblox simulé**
   (`game`, `Enum`, `Instance`, `HttpGet`, `loadstring`, `getgenv`, …).
2. Chaque appel d'API, assignation, `loadstring(...)`, `task.spawn(function() ... end)`,
   etc. est enregistré.
3. Le journal est reconstruit en un script Lua lisible (`nom.deobf.lua`).
4. `EncodingService:DecompressBuffer` (Zstd, utilisé par Luraph 14.x) est implémenté
   pour de vrai (`fzstd`) ; les payloads passés à `loadstring` sont sauvegardés et exécutés
   dans la même sandbox (déobfuscation multi-couches).

Rien n'est exécuté sur votre machine : le code tourne dans le WASM, avec des API factices.

## Installation sur Termux

```bash
pkg update && pkg upgrade -y
pkg install nodejs python -y

cd luraph-deobf          # le dossier de ce README
npm install              # (ou : sera fait automatiquement au 1er lancement de deobf.py)
```

Dépendances npm : `luau-web` et `fzstd` — 100 % JavaScript/WASM, aucune compilation native
(donc pas de `node-gyp`, pas de problème sous Android/Termux).

## Utilisation

```bash
# Un fichier
python deobf.py "/sdcard/Download/script.lua"

# Un dossier entier (tous les .lua / .luau / .txt ; -r pour les sous-dossiers)
python deobf.py "/sdcard/Download/mes_scripts" -r

# Directement avec Node
node deobf.mjs script.lua
```

Les résultats sont écrits dans `deobf_out/` (à côté du fichier, ou dans `<dossier>/deobf_out`).

| Fichier | Contenu |
|---|---|
| `nom.deobf.lua` | script reconstruit |
| `nom.payloadN.lua` | chaque chaîne passée à `loadstring()` |
| `nom.blobN.bin` | bytecode décompressé (Zstd) |
| `nom.report.txt` | analyse statique, URLs, appels sensibles, chaînes |

### Options

```
-o, --out <dossier>   dossier de sortie
-t, --timeout <sec>   temps max par script (défaut 25)
-r, --recursive       sous-dossiers
    --no-callbacks    ne pas tracer l'intérieur des callbacks
    --no-inline       garder les variables temporaires v1, v2…
    --place-id <id>   PlaceId simulé
    --max-lines <n>   limite de lignes émises (défaut 30000)
    --normalize       écrit aussi le script d'origine avec littéraux numériques normalisés
    --stdout          affiche le résultat dans le terminal
-q, --quiet           moins de messages
```

## Limites connues

* Les variantes de Luraph v14.7 « VM lourde » (celles qui commencent par
  `return({xx=function…` ou `return(function()local …` avec un gros bytecode de
  plusieurs centaines de Ko) exécutent une VM *dans* la VM Luau/WASM : c'est très lent
  (plusieurs minutes, voire plus sur téléphone) et certaines lient leur démarrage à des
  comportements exacts du moteur Roblox. Augmentez alors `-t` (ex. `-t 900`). En cas de
  timeout, la trace partielle déjà capturée est quand même écrite.
* Les scripts de plus d'~1 Mo peuvent faire échouer le compilateur Luau/WASM
  (`memory access out of bounds`).
* La sandbox ne fait **jamais** de vraies requêtes réseau : `HttpGet` renvoie une chaîne vide,
  vous obtenez donc l'URL appelée, pas le contenu distant.
