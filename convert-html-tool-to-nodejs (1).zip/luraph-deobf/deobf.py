#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Lanceur Python pour luraph-deobf (le moteur est écrit en Node.js).

Usage (Termux ou autre) :
    python deobf.py "chemin/vers/script.lua"
    python deobf.py "chemin/vers/dossier"          # traite tous les .lua du dossier
    python deobf.py "script.lua" -t 60 -o sortie   # options : voir --help

Au premier lancement, les dépendances npm (luau-web, fzstd) sont installées
automatiquement si nécessaire.
"""
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ENTRY = os.path.join(HERE, "deobf.mjs")


def die(msg, code=2):
    sys.stderr.write("\n[x] " + msg + "\n")
    sys.exit(code)


def main():
    node = shutil.which("node") or shutil.which("nodejs")
    if not node:
        die(
            "Node.js est introuvable.\n"
            "    Sur Termux :  pkg update && pkg install nodejs\n"
            "    Ailleurs   :  https://nodejs.org/",
        )

    # Dépendances : installation automatique au premier lancement
    if not os.path.isdir(os.path.join(HERE, "node_modules", "luau-web")):
        npm = shutil.which("npm")
        if not npm:
            die("npm est introuvable (Termux : pkg install nodejs).")
        print("[*] Première utilisation : installation des dépendances npm...")
        r = subprocess.call([npm, "install", "--no-audit", "--no-fund", "--loglevel=error"], cwd=HERE)
        if r != 0:
            die("echec de « npm install » (connexion internet requise la première fois).", r)

    args = sys.argv[1:]
    if not args:
        args = ["--help"]

    # Les chemins relatifs sont résolus depuis le dossier où l'on a lancé la commande.
    try:
        r = subprocess.call([node, ENTRY] + args, cwd=os.getcwd())
    except KeyboardInterrupt:
        r = 130
    sys.exit(r)


if __name__ == "__main__":
    main()
