#!/usr/bin/env node
// ============================================================================
//  luraph-deobf — Désobfuscateur Luraph en ligne de commande (Node.js / Termux)
//
//  Le script cible est exécuté dans une sandbox Luau (WASM) qui simule
//  l'environnement Roblox. Tous les appels d'API, assignations, payloads
//  loadstring, etc. sont enregistrés puis reconstruits en un script lisible.
//
//  Usage :
//    node deobf.mjs <fichier.lua | dossier> [options]
//    python deobf.py <fichier.lua | dossier> [options]     (lanceur Python)
// ============================================================================
import { Worker } from "node:worker_threads";
import { readFileSync, writeFileSync, readdirSync, statSync, mkdirSync, existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join, basename, extname, resolve } from "node:path";
import { applyOps, extractRemoteCalls, extractStrings, extractUrls, newState, render } from "./src/compose.mjs";
import { analyze, fmtBytes, normalizeLiterals } from "./src/static.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const WORKER = join(here, "src", "worker.mjs");

// ------------------------------------------------------------------- couleurs
const useColor = process.stdout.isTTY && !process.env.NO_COLOR;
const c = (code, s) => (useColor ? `\x1b[${code}m${s}\x1b[0m` : String(s));
const bold = (s) => c("1", s);
const dim = (s) => c("2", s);
const red = (s) => c("31", s);
const green = (s) => c("32", s);
const yellow = (s) => c("33", s);
const cyan = (s) => c("36", s);

// ------------------------------------------------------------------- arguments
const HELP = `
${bold("luraph-deobf")} — désobfuscateur Luraph (sandbox Luau/WASM)

${bold("Usage")}
  node deobf.mjs <fichier.lua | dossier> [options]
  python deobf.py <fichier.lua | dossier> [options]

${bold("Options")}
  -o, --out <dossier>     Dossier de sortie (défaut : <cible>/deobf_out ou ./deobf_out)
  -t, --timeout <sec>     Temps max par script (défaut : 25)
  -r, --recursive         Parcourir les sous-dossiers (si la cible est un dossier)
      --no-callbacks      Ne pas tracer le contenu des callbacks (function() ... end)
      --no-inline         Ne pas fusionner les variables temporaires (v1, v2...)
      --place-id <id>     PlaceId simulé pour game.PlaceId / game.GameId
      --max-lines <n>     Nombre max de lignes émises (défaut : 30000)
      --normalize         Écrit aussi une version du script d'origine avec littéraux
                          numériques normalisés (0X27__D3 -> décimal)
      --stdout            Affiche le résultat dans le terminal (fichier unique)
  -q, --quiet             Moins de messages
  -h, --help              Affiche cette aide

${bold("Sorties")} (dans le dossier de sortie, pour « nom.lua »)
  nom.deobf.lua           Script reconstruit
  nom.payloadN.lua        Chaque chaîne passée à loadstring()
  nom.blobN.bin           Bytecode décompressé (Zstd / EncodingService)
  nom.report.txt          Analyse statique, URLs, appels distants, chaînes
`;

function parseArgs(argv) {
  const o = {
    target: null, out: null, timeout: 25, recursive: false, runCallbacks: true, inline: true,
    placeId: undefined, maxLines: undefined, normalize: false, stdout: false, quiet: false,
  };
  const need = (i, name) => {
    if (i + 1 >= argv.length) fail(`Option ${name} : valeur manquante`);
    return argv[i + 1];
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    switch (a) {
      case "-h": case "--help": console.log(HELP); process.exit(0); break;
      case "-o": case "--out": o.out = need(i, a); i++; break;
      case "-t": case "--timeout": o.timeout = Number(need(i, a)); i++; break;
      case "-r": case "--recursive": o.recursive = true; break;
      case "--no-callbacks": o.runCallbacks = false; break;
      case "--no-inline": o.inline = false; break;
      case "--place-id": o.placeId = Number(need(i, a)); i++; break;
      case "--max-lines": o.maxLines = Number(need(i, a)); i++; break;
      case "--normalize": o.normalize = true; break;
      case "--stdout": o.stdout = true; break;
      case "-q": case "--quiet": o.quiet = true; break;
      default:
        if (a.startsWith("-") && a.length > 1) fail(`Option inconnue : ${a}  (voir --help)`);
        if (o.target) fail(`Une seule cible attendue (reçu : « ${o.target} » et « ${a} »)`);
        o.target = a;
    }
  }
  if (!o.target) {
    console.log(HELP);
    process.exit(1);
  }
  if (!Number.isFinite(o.timeout) || o.timeout <= 0) fail("--timeout doit être un nombre > 0");
  return o;
}

function fail(msg) {
  console.error(red("✗ ") + msg);
  process.exit(2);
}

// ------------------------------------------------------------------- fichiers
const LUA_EXT = new Set([".lua", ".luau", ".txt"]);

function collect(dir, recursive, outDir) {
  const res = [];
  for (const name of readdirSync(dir).sort()) {
    const p = join(dir, name);
    let st;
    try { st = statSync(p); } catch { continue; }
    if (st.isDirectory()) {
      if (recursive && resolve(p) !== resolve(outDir) && name !== "node_modules" && !name.startsWith(".")) {
        res.push(...collect(p, recursive, outDir));
      }
    } else if (LUA_EXT.has(extname(name).toLowerCase()) && !/\.(deobf|payload\d+|normalized)\.lua$/i.test(name)) {
      res.push(p);
    }
  }
  return res;
}

// ------------------------------------------------------------------- sandbox
function runInWorker(source, opts) {
  return new Promise((resolvePromise) => {
    const state = newState();
    let finished = false;
    let fatal = "";
    const t0 = Date.now();
    const worker = new Worker(WORKER, {
      stderr: true, // on capture les messages bruts du WASM (ex. « Cannot enlarge memory »)
      workerData: {
        source,
        options: { runCallbacks: opts.runCallbacks, placeId: opts.placeId, maxLines: opts.maxLines },
      },
    });
    let wasmNote = "";
    worker.stderr.on("data", (d) => {
      const t = String(d).trim();
      if (t) wasmNote = t.split("\n")[0].slice(0, 120);
      if (process.env.LURAPH_DEBUG) process.stderr.write(d);
    });
    const end = (status) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      worker.terminate().catch(() => {});
      resolvePromise({ state, status, fatal, ms: Date.now() - t0, wasmNote });
    };
    const timer = setTimeout(() => end("timeout"), opts.timeout * 1000);
    worker.on("message", (m) => {
      if (m.type === "ops") applyOps(state, m.ops);
      else if (m.type === "done") end("done:" + m.result);
      else if (m.type === "fatal") { fatal = m.message; end("fatal"); }
    });
    worker.on("error", (e) => { fatal = String((e && e.message) || e); end("fatal"); });
    worker.on("exit", () => end(fatal ? "fatal" : "done:ok"));
  });
}

// ------------------------------------------------------------------- traitement
function safeBase(file) {
  return basename(file).replace(/\.[^.]+$/, "") || "script";
}

async function processFile(file, opts, outDir) {
  const raw = readFileSync(file);
  const source = raw.toString("utf8");
  const base = safeBase(file);
  const log = (...a) => { if (!opts.quiet) console.log(...a); };

  log(`\n${bold("▶ " + file)} ${dim("(" + fmtBytes(raw.length) + ")")}`);
  if (!source.trim()) {
    console.log(yellow("  ! fichier vide, ignoré"));
    return { ok: false };
  }

  const rep = analyze(source);
  log(`  ${cyan("Type")}      : ${rep.luraph ? "Luraph" : "Non-Luraph / inconnu"}${rep.version ? " v" + rep.version : ""} — ${rep.flavor}`);
  if (rep.markers.length) log(`  ${cyan("Marqueurs")} : ${rep.markers.join(", ")}`);

  log(`  ${dim("Exécution en sandbox (timeout " + opts.timeout + " s)…")}`);
  const { state, status, fatal, ms, wasmNote } = await runInWorker(source, opts);

  if (status === "fatal") {
    console.log(red(`  ✗ erreur fatale du moteur : ${fatal}`));
  }
  const { code, lineCount } = render(state, { inline: opts.inline });
  const statusTxt =
    status === "timeout" ? yellow("timeout (résultat partiel)")
    : status === "fatal" ? red("erreur")
    : status.endsWith("error") ? yellow("terminé (le script a levé une erreur, trace partielle)")
    : status.endsWith("syntax") ? red("erreur de syntaxe dans le script")
    : green("terminé");
  log(`  ${cyan("Statut")}    : ${statusTxt} en ${(ms / 1000).toFixed(2)} s`);

  if (wasmNote) log(`  ${dim("Note sandbox : " + wasmNote + " (le script tente une allocation énorme, ignoré)")}`);

  if (lineCount === 0) {
    console.log(yellow("  ! aucune ligne produite — aucun appel d'API observé"));
    if (status === "timeout") {
      console.log(yellow(`  ! la VM Luraph tourne encore : réessayez avec un délai plus long, ex. -t ${Math.round(opts.timeout * 6)}`));
    }
    if (state.blobs.length && !opts.stdout) {
      mkdirSync(outDir, { recursive: true });
      state.blobs.forEach((b, i) => writeFileSync(join(outDir, `${base}.blob${i + 1}.bin`), Buffer.from(b.hex, "hex")));
      console.log(dim(`    bytecode décompressé (${fmtBytes(state.blobs[0].size)}) sauvegardé dans ${outDir}`));
    }
    return { ok: false, lineCount: 0 };
  }

  // ---- écriture
  const header =
    `-- Reconstruit par luraph-deobf (sandbox Luau/WASM)\n` +
    `-- Source : ${basename(file)}${rep.version ? "  (Luraph v" + rep.version + ")" : ""}\n` +
    `-- Les variables vN / fnN / aN sont des noms générés automatiquement.\n\n`;

  if (opts.stdout) {
    process.stdout.write(code + "\n");
  } else {
    mkdirSync(outDir, { recursive: true });
  }
  const outFile = join(outDir, `${base}.deobf.lua`);
  if (!opts.stdout) writeFileSync(outFile, header + code + "\n");

  const written = [];
  if (!opts.stdout) {
    written.push(outFile);
    state.payloads.forEach((p, i) => {
      const f = join(outDir, `${base}.payload${i + 1}.lua`);
      writeFileSync(f, p.source);
      written.push(f);
    });
    state.blobs.forEach((b, i) => {
      const f = join(outDir, `${base}.blob${i + 1}.bin`);
      writeFileSync(f, Buffer.from(b.hex, "hex"));
      written.push(f);
    });
    if (opts.normalize) {
      const f = join(outDir, `${base}.normalized.lua`);
      writeFileSync(f, normalizeLiterals(source));
      written.push(f);
    }
  }

  // ---- rapport
  const texts = [code, ...state.payloads.map((p) => p.source)];
  const urls = extractUrls(texts);
  const remote = extractRemoteCalls(code);
  const strings = extractStrings(code);

  if (!opts.stdout) {
    const lines = [];
    lines.push(`Rapport luraph-deobf — ${basename(file)}`);
    lines.push("=".repeat(60));
    lines.push(`Taille            : ${raw.length} octets (${rep.lines} lignes, plus longue : ${rep.longestLine})`);
    lines.push(`Luraph            : ${rep.luraph ? "oui" : "non"}${rep.version ? " v" + rep.version : ""}`);
    lines.push(`Variante          : ${rep.flavor}`);
    lines.push(`Note              : ${rep.flavorNote}`);
    lines.push(`Marqueurs         : ${rep.markers.join(", ") || "—"}`);
    lines.push(`Statut sandbox    : ${status} (${ms} ms)`);
    lines.push(`Lignes produites  : ${lineCount}`);
    lines.push(`Payloads          : ${state.payloads.length}`);
    lines.push(`Blobs décompressés: ${state.blobs.length} (${fmtBytes(state.blobs.reduce((a, b) => a + b.size, 0))})`);
    lines.push("", `--- URLs (${urls.length}) ---`, ...urls);
    lines.push("", `--- Appels sensibles (${remote.length}) ---`, ...remote);
    lines.push("", `--- Chaînes (${strings.length}) ---`, ...strings.slice(0, 2000));
    const rf = join(outDir, `${base}.report.txt`);
    writeFileSync(rf, lines.join("\n") + "\n");
    written.push(rf);
  }

  log(`  ${cyan("Résultat")}  : ${bold(String(lineCount))} lignes, ${state.payloads.length} payload(s), ${state.blobs.length} blob(s), ${urls.length} URL(s)`);
  if (state.blobs.length) {
    log(`  ${dim("Bytecode décompressé via Zstd : " + fmtBytes(state.blobs.reduce((a, b) => a + b.size, 0)))}`);
  }
  if (urls.length) {
    log(`  ${cyan("URLs")} :`);
    urls.slice(0, 8).forEach((u) => log("    - " + (u.length > 110 ? u.slice(0, 110) + "…" : u)));
    if (urls.length > 8) log(dim(`    … +${urls.length - 8} autres (voir le rapport)`));
  }
  if (!opts.stdout) {
    log(`  ${green("✔ écrit")} : ${outFile}`);
    if (written.length > 1) log(dim(`    (+ ${written.length - 1} fichier(s) annexe(s))`));
  }
  return { ok: true, lineCount, status, payloads: state.payloads.length, urls: urls.length };
}

async function main() {
  const opts = parseArgs(process.argv.slice(2));
  const target = resolve(opts.target);
  if (!existsSync(target)) fail(`Introuvable : ${opts.target}`);

  const st = statSync(target);
  let files;
  let outDir;
  if (st.isDirectory()) {
    outDir = resolve(opts.out || join(target, "deobf_out"));
    files = collect(target, opts.recursive, outDir);
    if (!files.length) fail(`Aucun fichier .lua / .luau / .txt dans ${opts.target}${opts.recursive ? "" : "  (essayez -r pour les sous-dossiers)"}`);
  } else {
    outDir = resolve(opts.out || join(dirname(target), "deobf_out"));
    files = [target];
  }
  if (opts.stdout && files.length > 1) fail("--stdout ne fonctionne qu'avec un fichier unique");

  if (!opts.quiet) console.log(bold(`luraph-deobf`) + dim(`  — ${files.length} fichier(s)`));

  let ok = 0, ko = 0;
  for (const f of files) {
    try {
      const r = await processFile(f, opts, outDir);
      if (r.ok) ok++; else ko++;
    } catch (e) {
      ko++;
      console.log(red(`  ✗ ${f} : ${(e && e.message) || e}`));
    }
  }
  if (files.length > 1) {
    console.log(`\n${bold("Terminé")} : ${green(ok + " réussi(s)")}, ${ko ? red(ko + " échec(s)") : "0 échec"}  → ${outDir}`);
  }
  process.exit(ok > 0 ? 0 : 1);
}

main().catch((e) => {
  console.error(red("✗ Erreur inattendue : ") + ((e && e.stack) || e));
  process.exit(1);
});
