export default function HomePage() {
  const steps = [
    "pkg update && pkg install nodejs python -y",
    "cd luraph-deobf",
    "npm install",
    'python deobf.py "/sdcard/Download/script.lua"',
  ];
  return (
    <main className="mx-auto max-w-3xl px-6 py-12">
      <p className="text-sm uppercase tracking-widest text-slate-500">Outil en ligne de commande</p>
      <h1 className="mt-3 text-4xl font-semibold text-slate-950">luraph-deobf</h1>
      <p className="mt-4 text-slate-700">
        Version Node.js (compatible Termux) de l&apos;outil HTML de désobfuscation Luraph. Le script est exécuté
        dans une sandbox Luau/WASM avec un environnement Roblox simulé ; chaque appel d&apos;API est enregistré
        puis reconstruit en un script Lua lisible.
      </p>

      <section className="mt-8 rounded-2xl bg-white p-6 shadow">
        <h2 className="text-lg font-semibold">Utilisation sur Termux</h2>
        <pre className="mt-3 overflow-x-auto rounded-lg bg-slate-900 p-4 text-sm text-emerald-300">
          {steps.join("\n")}
        </pre>
        <p className="mt-3 text-sm text-slate-600">
          Le premier argument de <code>deobf.py</code> peut être un fichier <code>.lua</code> ou un dossier
          (option <code>-r</code> pour les sous-dossiers). Les résultats sont écrits dans <code>deobf_out/</code>.
        </p>
      </section>

      <section className="mt-6 rounded-2xl bg-white p-6 shadow">
        <h2 className="text-lg font-semibold">Fichiers du projet</h2>
        <ul className="mt-3 list-disc space-y-1 pl-5 text-sm text-slate-700">
          <li><code>luraph-deobf/deobf.py</code> — lanceur Python (installe les dépendances au 1er lancement)</li>
          <li><code>luraph-deobf/deobf.mjs</code> — outil CLI Node.js</li>
          <li><code>luraph-deobf/src/</code> — moteur (sandbox, harnais Lua, reconstruction)</li>
          <li><code>luraph-deobf/README.md</code> — documentation et limites connues</li>
        </ul>
      </section>
    </main>
  );
}
